import javax.crypto.BadPaddingException;  
import javax.crypto.Cipher;  
import javax.crypto.IllegalBlockSizeException;  
import javax.crypto.NoSuchPaddingException;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;  
import java.security.PrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;  

public class ZGEncryptor {
//	throw NoSuchAlgoritheException,
//	NoSuchPaddingException,InvalidKeyException,
//	IllegalBlockSizeException,BadPaddingException
	//解密
	public String decrypte(PrivateKey privateKey,byte[] data)  {
		Cipher cipher = null;
		try {
			cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			cipher.init(Cipher.DECRYPT_MODE,privateKey);
		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		byte[] decryptedData = null;
		try {
			decryptedData = cipher.doFinal(data);
		} catch (IllegalBlockSizeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BadPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new String(decryptedData);
	}
	//加密
	public byte[] encrypte(String base64Text) {
		return Base64.getDecoder().decode(base64Text.getBytes(Charset.forName("UTF-8")));
	}
	//读取私钥
	public PrivateKey readPrivateKey() {
		byte[] privateKeyData = null;
		try {
			privateKeyData = Files.readAllBytes(Paths.get("/Users/zhanggui/Desktop/pkcs8_private_key.pem"));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		byte[] decodeKeyData = Base64.getDecoder()
				.decode(new String(privateKeyData)
						.replaceAll("-----\\w+ PRIVATE KEY-----","")
						.replace("\n", ""));
		
				
		try {
			return KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(decodeKeyData));
		} catch (InvalidKeySpecException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}


































