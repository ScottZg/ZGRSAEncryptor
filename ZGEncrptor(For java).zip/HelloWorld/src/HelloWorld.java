import java.security.PrivateKey;

public class HelloWorld {

	public static void main(String[] args) {
		ZGEncryptor rsa = new ZGEncryptor();
		PrivateKey privateKey = rsa.readPrivateKey();
		
		String message = "X7ak3iy5e3C+rRCVI4BOITD1T82btZ2/kTwcfnvEHjQFQywC3Q8nHd7M51/RsJYu63M4vApTsQpj1cWOMZmdz2h+saCJtdt3deA0PNzmuWDf14mdvg34Z+83j1QVjerON5C8GZfKhN/MOAY0xr8cc5bvKVy0UCXEonK9H6KY4Fg=";
	
		byte[] data = rsa.encrypte(message);
		String text = rsa.decrypte(privateKey, data);
		System.out.println(text);
	}
	public void go() {
		
	}

}